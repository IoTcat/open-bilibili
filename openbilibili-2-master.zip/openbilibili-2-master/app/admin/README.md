# go-common/app/admin

运营管理服务
